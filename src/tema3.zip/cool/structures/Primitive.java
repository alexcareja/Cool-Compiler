package cool.structures;

public class Primitive {
    // Symboluri aferente tipurilor, definite global
    public static TypeSymbol OBJECT;
    public static TypeSymbol INT;
    public static TypeSymbol STRING;
    public static TypeSymbol BOOL;
    public static TypeSymbol IO;
    public static TypeSymbol SELF_TYPE;
}